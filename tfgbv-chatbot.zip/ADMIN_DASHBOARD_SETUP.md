# Admin Dashboard Setup Guide

This guide will help you set up the admin dashboard with Supabase integration for the TFGBV Chatbot.

## Prerequisites

1. A Supabase account (https://supabase.com)
2. Node.js and npm installed
3. Required npm packages

## Step 1: Install Required Dependencies

Run the following command in your project root:

```bash
npm install @supabase/supabase-js bcryptjs jsonwebtoken uuid
```

Or if you use yarn:

```bash
yarn add @supabase/supabase-js bcryptjs jsonwebtoken uuid
```

## Step 2: Set Up Supabase Database

1. Go to your Supabase project dashboard
2. Navigate to the SQL Editor
3. Open the file `supabase-schema.sql` in your project root
4. Copy and paste the entire SQL script into the Supabase SQL Editor
5. Click "Run" to execute the script

This will create:
- `chat_messages` table - stores all chat messages
- `admin_users` table - stores admin credentials
- Necessary indexes for performance
- Row Level Security policies
- Default admin user (email: admin@uksfeminist.ai, password: Admin@123)

## Step 3: Configure Environment Variables

Add the following environment variables to your `.env.local` file:

```env
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Environment (development or production)
NEXT_PUBLIC_ENV=development

# JWT Secret (change this to a strong random string)
JWT_SECRET=your-secret-jwt-key-change-this-in-production

# OpenAI API Key (existing)
OPENAI_API_KEY=your_openai_api_key
```

### How to Get Supabase Credentials:

1. Go to your Supabase project dashboard
2. Click on "Settings" (gear icon)
3. Navigate to "API"
4. Copy the "Project URL" → This is your `NEXT_PUBLIC_SUPABASE_URL`
5. Copy the "anon/public" key → This is your `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## Step 4: Update Default Admin Password (IMPORTANT!)

For security, you should change the default admin password:

1. Generate a bcrypt hash for your new password:
   ```javascript
   const bcrypt = require('bcryptjs');
   const hash = bcrypt.hashSync('YourNewPassword', 10);
   console.log(hash);
   ```

2. In Supabase SQL Editor, run:
   ```sql
   UPDATE admin_users
   SET password_hash = 'your_new_bcrypt_hash_here'
   WHERE email = 'admin@uksfeminist.ai';
   ```

Or create a new admin user:
```sql
INSERT INTO admin_users (email, password_hash)
VALUES ('your-email@example.com', 'your_bcrypt_hash_here');
```

## Step 5: Start Your Application

```bash
npm run dev
```

## Step 6: Access Admin Dashboard

1. Navigate to `http://localhost:3000/admin/login`
2. Login with credentials:
   - Email: `admin@uksfeminist.ai`
   - Password: `Admin@123` (or your new password)
3. After successful login, you'll be redirected to the dashboard

## Features

### Admin Dashboard Features:
- **Environment Filter**: Switch between Development and Production data
- **Mode Filter**: Filter messages by:
  - All
  - Support
  - Analyzer
  - Bias Detector
  - Feminist Lens
  - Rewrite Engine
- **Session Grouping**: Messages are grouped by session ID
- **Real-time Refresh**: Manually refresh data with the refresh button
- **Message Display**: View all user and assistant messages with timestamps

### Chat Features:
- All chat messages are automatically saved to Supabase
- Each chat session has a unique session ID
- Messages are tagged with environment (development/production)
- Messages are tagged with mode (support, analyzer, etc.)

## Environment-Based Data Filtering

The system uses the `NEXT_PUBLIC_ENV` environment variable to tag messages:

- Set `NEXT_PUBLIC_ENV=development` in `.env.local` for development
- Set `NEXT_PUBLIC_ENV=production` in production (Vercel environment variables)

In the admin dashboard, you can switch between environments to view:
- **Development**: Test data from development environment
- **Production**: Real user data from production

## Troubleshooting

### Issue: "Missing Supabase environment variables"
**Solution**: Make sure you've added `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to your `.env.local` file.

### Issue: Cannot login to admin dashboard
**Solution**:
1. Check that the SQL schema was executed successfully in Supabase
2. Verify the admin user exists in the `admin_users` table
3. Check browser console for error messages

### Issue: Messages not appearing in dashboard
**Solution**:
1. Check that messages are being saved (look in Supabase table editor)
2. Verify the environment filter matches your current environment
3. Click the refresh button to reload data

### Issue: 401 Unauthorized when fetching messages
**Solution**:
1. Your JWT token may have expired (24h expiry)
2. Logout and login again
3. Check that `JWT_SECRET` is set in environment variables

## Security Considerations

1. **Change default password**: The default admin password should be changed immediately
2. **Use strong JWT_SECRET**: Generate a strong random string for production
3. **Enable HTTPS**: Always use HTTPS in production
4. **Row Level Security**: The Supabase tables have RLS enabled
5. **Token expiry**: Admin tokens expire after 24 hours

## Database Schema

### chat_messages table:
- `id`: UUID (primary key)
- `session_id`: UUID (groups messages by session)
- `mode`: TEXT (support, analyzer, bias-detector, feminist-lens, rewrite-engine)
- `role`: TEXT (user or assistant)
- `content`: TEXT (message content)
- `timestamp`: TIMESTAMPTZ (message timestamp)
- `environment`: TEXT (development or production)
- `created_at`: TIMESTAMPTZ (record creation time)

### admin_users table:
- `id`: UUID (primary key)
- `email`: TEXT (unique, admin email)
- `password_hash`: TEXT (bcrypt hashed password)
- `created_at`: TIMESTAMPTZ (account creation time)

## Next Steps

1. Test the chat functionality and verify messages are being saved
2. Test the admin login and dashboard
3. Change the default admin password
4. Set up proper environment variables in Vercel for production
5. Consider adding more admin features (export data, delete sessions, etc.)

## Support

If you encounter any issues, check:
1. Browser console for JavaScript errors
2. Supabase logs in the Supabase dashboard
3. Network tab for API request/response details
