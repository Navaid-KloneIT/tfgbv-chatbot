// Generate bcrypt hash for admin password
// Run with: node generate-admin-hash.js

const bcrypt = require('bcryptjs');

// Change this to your desired password
const password = 'Admin@123';

// Generate hash
const hash = bcrypt.hashSync(password, 10);

console.log('\n=================================');
console.log('Password:', password);
console.log('Bcrypt Hash:', hash);
console.log('=================================\n');
console.log('Run this SQL in MySQL (phpMyAdmin or CLI):\n');
console.log(`UPDATE admin_users SET password_hash = '${hash}' WHERE email = 'admin@uksfeminist.ai';`);
console.log('\n');
